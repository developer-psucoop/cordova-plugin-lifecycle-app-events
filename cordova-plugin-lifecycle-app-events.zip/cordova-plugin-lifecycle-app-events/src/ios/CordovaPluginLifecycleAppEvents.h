#import <Cordova/CDVPlugin.h>

@interface CordovaPluginLifecycleAppEvents : CDVPlugin {}

@end
